#include <iostream>

using namespace std;

int main()
{
	cout << "They can't, they're still figuring out how to change the tire.\n";
	return 0;
}
